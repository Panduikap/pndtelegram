import time, warnings, json, os, base64
with warnings.catch_warnings():
	warnings.filterwarnings("ignore",category=DeprecationWarning)
	from selenium import webdriver
	from selenium.common.exceptions import (NoSuchElementException, StaleElementReferenceException)
	from selenium.webdriver.firefox.options import Options
	from selenium.webdriver.common.by import By
	from selenium.webdriver.support import expected_conditions as EC
	from selenium.webdriver.support.ui import WebDriverWait
	from selenium.webdriver.common.desired_capabilities import DesiredCapabilities
	from selenium.webdriver.common.action_chains import ActionChains
	from selenium.webdriver.common.keys import Keys
	
class Prepare:
	def __init__(kimin, url, browser, browser_path, driver_path, profil_path):
		kimin.url = url
		kimin.browser = browser
		kimin.browser_path = browser_path
		kimin.profil_path = profil_path
		kimin.user_agent = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:108.0) Gecko/20100101 Firefox/108.0'
		kimin.driver_path = driver_path
		kimin.driver = kimin.GetDriver(driver_path)
		
	
	def GetDriver(kimin, driver):
		if kimin.browser == "firefox":
			options = Options()
			options.binary_location = kimin.browser_path
			options.headless = True
			options.add_argument("-profile")
			options.add_argument(kimin.profil_path)
			options.set_preference("general.useragent.override", kimin.user_agent)
			options.set_preference("app.update.auto", False)
			options.set_preference("app.update.lastUpdateTime.addon-background-update-timer", 1280826385)
			options.set_preference("app.update.lastUpdateTime.background-update-timer", 1280826385)
			options.set_preference("app.update.lastUpdateTime.blocklist-background-update-timer", 1280826385)
			options.set_preference("app.update.lastUpdateTime.microsummary-generator-update-timer", 1280502030)
			options.set_preference("app.update.lastUpdateTime.places-maintenance-timer", 1280826385)
			options.set_preference("app.update.lastUpdateTime.search-engine-update-timer", 1280826385)
			options.set_preference("browser.EULA.3.accepted", True)
			options.set_preference("browser.EULA.override", True)
			options.set_preference("browser.allowpopups", True)
			options.set_preference("browser.bookmarks.restore_default_bookmarks", False)
			options.set_preference("browser.download.manager.showWhenStarting", False)
			options.set_preference("browser.history_expire_days.mirror", 180)
			options.set_preference("browser.link.open_external", 2)
			options.set_preference("browser.migration.version", 1)
			options.set_preference("browser.places.smartBookmarksVersion", 1)
			options.set_preference("browser.preferences.advanced.selectedTabIndex", 2)
			# options.set_preference("browser.privatebrowsing.autostart", True)
			options.set_preference("browser.rights.3.shown", True)
			options.set_preference("browser.safebrowsing.enabled", False)
			options.set_preference("browser.search.update", False)
			options.set_preference("browser.sessionstore.resume_session_once", True)
			options.set_preference("browser.startup.homepage", "about:blank")
			options.set_preference("browser.startup.homepage_override.mstone", "rv:1.9.1.11")
			options.set_preference("browser.startup.page", 0)
			options.set_preference("browser.tabs.warnOnClose", False)
			options.set_preference("browser.tabs.warnOnOpen", False)
			options.set_preference("browser.urlbar.autocomplete.enabled", False)
			options.set_preference("dom.disable_open_during_load", False)
			options.set_preference("dom.max_chrome_script_run_time", 1800)
			options.set_preference("dom.max_script_run_time", 1800)
			options.set_preference("extensions.lastAppVersion", "3.5.11")
			options.set_preference("extensions.update.enabled", False)
			options.set_preference("extensions.update.notifyUser", False)
			options.set_preference("idle.lastDailyNotification", 1280826384)
			options.set_preference("intl.charsetmenu.browser.cache", "UTF-8, ISO-8859-1")
			options.set_preference("network.cookie.prefsMigrated", True)
			options.set_preference("network.dns.disableIPv6", True)
			options.set_preference("network.http.phishy-userpass-length", 255)
			options.set_preference("pref.browser.homepage.disable_button.bookmark_page", False)
			options.set_preference("pref.browser.homepage.disable_button.current_page", False)
			options.set_preference("pref.browser.homepage.disable_button.restore_default", False)
			options.set_preference("privacy.sanitize.migrateFx3Prefs", True)
			options.set_preference("privacy.sanitize.timeSpan", 0)
			options.set_preference("security.warn_entering_weak", False)
			options.set_preference("security.warn_entering_weak.show_once", False)
			options.set_preference("security.warn_viewing_mixed", False)
			options.set_preference("security.warn_viewing_mixed.show_once", False)
			options.set_preference("signon.rememberSignons", False)
			options.set_preference("spellchecker.dictionary", "en_US")
			options.set_preference("startup.homepage_welcome_url", "")
			options.set_preference("urlclassifier.keyupdatetime.https://sb-ssl.google.com/safebrowsing/newkey",1287053252)
			options.set_preference("xpinstall.whitelist.required", False)
			options.set_preference("browser.cache.disk.enable", False)
			options.set_preference("browser.cache.memory.enable", False)
			options.set_preference("browser.cache.offline.enable", False)
			options.set_preference("network.http.use-cache", False)
			firefox_capabilities = DesiredCapabilities.FIREFOX
			firefox_capabilities['marionette'] = True
			driver = webdriver.Firefox(executable_path=kimin.driver_path, options=options)
		return driver
	
	def Visit(kimin, driver):
		driver.get(kimin.url)