from selenium.common.exceptions import NoSuchElementException
from selenium.webdriver.common.by import By

class Parser:
	@staticmethod
	def GetHarga(driver, url):
		if not url.find('eraspace.com') == -1:
			try:
				hasil = driver.find_elements(By.XPATH, '//div[@class="text-4xl"]//div[@class="flex flex-col gap-0.5"]//span[@class="tracking-[0.03em] font-bold"]')
				for i in hasil:
					return i.text
			except Exception as e:
				print(f"Error Modul Parser Function GetHarga : {e}")
		
		elif not url.find('ibox.co.id') == -1:
			try:
				hasil = driver.find_elements(By.XPATH, '//div[@class="text-center card-body"]//p[@class="pdp-product-title m-0"]')
				for i in hasil:
					return i.text
			except Exception as e:
				print(f'Error Modul Parser Function GetHarga : {e}')
		
		elif not url.find('shopee.co.id') == -1:
			try:
				hasil = driver.find_elements(By.XPATH, '//div[@class="flex items-center"]//div[@class="pqTWkA"]')
				for i in hasil:
					return i.text
			except Exception as e:
				print(f'Error Modul Parser Function GetHarga : {e}')
		
	
	@staticmethod
	def GetNama(driver, url):
		if not url.find('eraspace.com') == -1:
			try:
				hasil = driver.find_elements(By.XPATH, '//h1[@id="pdp-product-title"]')
				for i in hasil:
					return i.text
			except Exception as e:
				print(f"Error Modul Parser Function GetNama : {e}")
		
		elif not url.find('ibox.co.id') == -1:
			try:
				hasil = driver.find_elements(By.XPATH, '//h1[@class="product-title pdp-product-title"]')
				for i in hasil:
					return i.text
			except Exception as e:
				print(f'Error Modul Parser Function GetNama : {e}')
		
		elif not url.find('shopee.co.id') == -1:
			try:
				hasil =  driver.find_elements(By.XPATH, '//div[@class="_44qnta"]//span')
				for i in hasil:
					return i.text
			except Exception as e:
				print(f'Error Modul Parser Function GetNama : {e}')

	@staticmethod
	def GetStock(driver, url):
		if not url.find('eraspace.com') == -1:
			try:
				# try:
				habis = driver.find_elements(By.XPATH, '//h3[@class="font-bold tracking-normal text-lg mb-1"]')
				# except AttributeError:
				if len(habis) > 0:
					return "Habis"
				
				elif len(habis) == 0:
					tersedia = driver.find_elements(By.XPATH, '//div[@class="text-4xl"]//span[@id="mcis-stok-tersedia"]')
					if len(tersedia) == 0:
						return "Terbatas"
					
					elif len(tersedia) >0:
						return "Tersedia"

			except Exception as e:
				print(f"Error Modul Parser Function GetStock : {e}")
		
		elif not url.find('ibox.co.id') == -1:
			try:
				return driver.find_elements(By.XPATH, '//div[@class="sc-eDvSVe cjdpgC"]//span')[0].text.split('\n')[1]
			except Exception as e:
				print(f"Error Modul Parser Function GetStock : {e}")
		
		elif not url.find('shopee.co.id') == -1:
			try:
				hasil = driver.find_elements(By.XPATH, '//div[@class="flex items-center _6lioXX"]//div[@class="flex items-center"]')
				for i in hasil:
					return i.text
				return 
			except Exception as e:
				print(f"Error Modul Parser Function GetStock : {e}")