from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.by import By
from selenium.common.exceptions import WebDriverException, NoSuchElementException
import time
from selenium.webdriver.common.keys import Keys
from random import randint
import logging

class Core_Ext:
	@staticmethod
	def tunggu_halaman(driver, url):
		if not url.find('eraspace.com') == -1:
			try:
				WebDriverWait(driver, 10).until(EC.presence_of_element_located(
					(By.CSS_SELECTOR, '[id="product-detail"]')))
			except WebDriverException:
				print(f"Masalah Saat Buka {url}")
		
		elif not url.find('ibox.co.id') == -1:
			try:
				WebDriverWait(driver, 10).until(EC.presence_of_element_located(
					(By.CSS_SELECTOR, '[id="favoritkan-button"]')))
			except WebDriverException:
				print(f"Masalah Saat Buka {url}")
		
		elif not url.find('shopee.co.id') == -1:
			try:
				WebDriverWait(driver, 10).until(EC.presence_of_element_located(
					(By.CSS_SELECTOR, '[data-testid="page_product"]')))
			except WebDriverException:
				print(f"Masalah Saat Buka {url}")