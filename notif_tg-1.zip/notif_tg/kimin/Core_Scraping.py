import json, os, requests, scrapy
from scrapy_splash import SplashRequest
token = None
temp_data = {}
user_id = None

class Notifikasi:
	def __init__(kimin):
		kimin.token = None
	
	@staticmethod
	def SetToken(data):
		global token
		token = data
	
	@staticmethod
	def SetID(data):
		global user_id
		user_id = data

	@staticmethod 
	def SetData(data):
		global temp_data
		temp_data = data
	
	def GetStat(kimin):
		if not os.path.exists('notif_stat.min'):
			with open('notif_stat.min', 'w') as dataku:
				dataku.write("")
	
		with open('notif_stat.min','r') as dataku:
			hasil = dataku.read().splitlines()
		
		return hasil
	
	def setStats(kimin, stat):
		with open('notif_stat.min', 'a') as dataku:
			dataku.write(f"{stat}\n")
	
	def Kirim_Pesan(kimin, id, text):
		elemen = f"https://api.telegram.org/bot{kimin.token}/sendMessage?chat_id={id}&text={text}"
		# try:
		requests.get(elemen)
		# except:
			# pass
				
class Scraping(scrapy.Spider):
	name = 'Kimin'
	def start_requests(kimin):
		for a in temp_data:
			# for i in a['link_produk']:
			if not a.find('shopee.co.id') == -1:
				headers={"User-Agent": "Mozilla/5.0 (compatible; Googlebot/2.1; +http://www.google.com/bot.html)"}
			elif not a.find('tokopedia.com') == -1:
				headers={"User-Agent": "Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 5.1)"}
			else:
				headers={"User-Agent": "Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:59.0) Gecko/20100101 Firefox/59.0"}
			
			yield SplashRequest(
				url=a, 
				callback=kimin.GetData,
				headers=headers,
				args={'wait': 0.5},
				endpoint='render.html')
	
	def Cleaning(kimin, text):
		hasil = []
		izin = [",",".","-","'",':', '(',')']
		
		for a in text:
			for b in a.split(' '):
				temp = ""
				for c in b:
					if c.isalpha() or c.isnumeric():
						temp = temp + c
					elif c in izin:
						temp = temp + c
					
				hasil.append(temp.strip().replace('\\"','"'))
	  
		hasil = " ".join(hasil).strip()
		return hasil
	
	def GetData(kimin, response):
		# page = response.url.replace("https://","").replace("/","--").replace("?","---")
		# filename = f'{page}.html'
		# with open(f"hasil.html", 'wb') as f:
			# f.write(response.body)
		
		
		if not response.url.find('tokopedia.com') == -1:
			nama = response.xpath('//h1[@data-testid="lblPDPDetailProductName"]//text()').extract()
			harga = response.xpath('//div[@class="css-1m72sg"]//div[@data-testid="lblPDPDetailProductPrice"]//text()').extract()
			stok = response.xpath('//div[@data-testid="quantityOrder"]//p[@data-testid="stock-label"]//b//text()').extract()
			kirim = response.xpath('//div[@class="css-1r5ugw9 pad-bottom"]/h2[@class="css-qnb3mv-unf-heading e1qvo2ff2"]//text()').extract()
		
		elif not response.url.find('shopee.co.id') == -1:
			nama = response.xpath('//div[@class="_44qnta"]//span//text()').extract()
			harga = response.xpath('//div[@class="flex items-center"]//div[@class="pqTWkA"]//text()').extract()
			temp = response.xpath('//div[@class="MCCLkq"]//div[@class="dR8kXc"]')
			stok = temp[len(temp)-2].xpath('.//div//text()').extract()
			kirim = temp[len(temp)-1].xpath('.//div//text()').extract()
		
		elif not response.url.find('ibox.co.id') == -1:
			temp = response.xpath('//script[@id="__NEXT_DATA__"]//text()').extract_first()
			data = json.loads(temp)
			nama = data['props']['pageProps']['dataProduct']['name']
			harga = data['props']['pageProps']['dataProduct']['price']
			try:
				spesial_harga = data['props']['pageProps']['dataProduct']['special_price']
			except KeyError:
				spesial_harga = None
			stok = data['props']['pageProps']['dataProduct']['stock_status']
		
		
		temp_stat = f"{response.url}||{stok}"
		sin = Notifikasi()
		sin.token = token
		stat = sin.GetStat()
		if not temp_stat in stat:
			sin.setStats(temp_stat)
			if not response.url.find('shopee.co.id') == -1:
				nama = kimin.Cleaning(nama)
				harga = kimin.Cleaning(harga)
				stok = kimin.Cleaning(stok)
				kirim = kimin.Cleaning(kirim)
			
				text = f"====================\nNama Produk  : {nama}\nHarga Produk : {harga}\nStok Produk  : {stok}\nDikirim Dari : {kirim}\n====================\n\nLink Produk  : {response.url}"
			elif not response.url.find('tokopedia.com') == -1:
				nama = kimin.Cleaning(nama)
				harga = kimin.Cleaning(harga)
				stok = kimin.Cleaning(stok)
				kirim = kimin.Cleaning(kirim)
			
				text = f"====================\nNama Produk  : {nama}\nHarga Produk : {harga}\nStok Produk  : {stok}\n====================\n\nLink Produk  : {response.url}"
			elif not response.url.find('ibox.co.id') == -1:
				if not spesial_harga is None:
					text = f"====================\nNama Produk  : {nama}\nHarga Normal : {harga}\nHarga Spesial : {spesial_harga}\nStok Produk     : {stok}\n====================\n\nLink Produk  : {response.url}"
				else:
					text = f"====================\nNama Produk  : {nama}\nHarga Normal : {harga}\nStok Produk     : {stok}\n====================\n\nLink Produk  : {response.url}"
			
			if not str(stok) == '0' and not str(stok) == "Habis":
				for i in user_id:
					sin.Kirim_Pesan(i, text)