import json, os, requests, scrapy
# with open('token.min','r') as dataku:
	# d1 = dataku.read()

# token = d1
temp_data = {}
class Notifikasi:
	def __init__(kimin):
		kimin.token = None
	
	@staticmethod 
	def SetData(data):
		global temp_data
		temp_data = data
	
	def GetStat(kimin):
		if not os.path.exists('db/notif_stat.ncs'):
			with open('db/notif_stat.ncs', 'w') as dataku:
				dataku.write("")
	
		with open('db/notif_stat.ncs','r') as dataku:
			hasil = dataku.read().splitlines()
		
		return hasil
	
	def setStats(kimin, stat):
		with open('db/notif_stat.ncs', 'a') as dataku:
			dataku.write(f"{stat}\n")
	
	def Kirim_Pesan(kimin, id, text):
		elemen = f"https://api.telegram.org/bot{kimin.token}/sendMessage?chat_id={i}&text={text}"
		try:
			requests.get(elemen)
		except:
			pass
				
class Scraping(scrapy.Spider):
	name = 'Kimin'
	def start_requests(kimin):
		for a in temp_data:
			for i in a['link_produk']:
				yield scrapy.Request(
					url=i, 
					callback=kimin.GetData, 
					cb_kwargs={
						'user_id':a['user_id']})
	
	def Cleaning(kimin, text):
		hasil = []
		izin = [",",".","-","'",':', '(',')']
		
		for a in text:
			for b in a.split(' '):
				temp = ""
				for c in b:
					if c.isalpha() or c.isnumeric():
						temp = temp + c
					elif c in izin:
						temp = temp + c
					
				hasil.append(temp.strip().replace('\\"','"'))
	  
		hasil = " ".join(hasil).strip()
		return hasil
	
	def GetData(kimin, response, user_id):
		# page = response.url.replace("https://","").replace("/","--").replace("?","---")
		# filename = f'{page}.html'
		# with open(f"{filename}", 'wb') as f:
			# f.write(response.body)
		
		nama = response.xpath('//div[@class="_44qnta"]//span//text()').extract()
		harga = response.xpath('//div[@class="flex items-center"]//div[@class="pqTWkA"]//text()').extract()
		temp = response.xpath('//div[@class="MCCLkq"]//div[@class="dR8kXc"]')
		stok = temp[len(temp)-2].xpath('.//div//text()').extract()
		kirim = temp[len(temp)-1].xpath('.//div//text()').extract()
		
		nama = kimin.Cleaning(nama)
		harga = kimin.Cleaning(harga)
		stok = kimin.Cleaning(stok)
		kirim = kimin.Cleaning(kirim)
		
		temp_stat = f"{response.url}||{stok}"
		sin = Notifikasi()
		sin.token = '5839946416:AAHNnDVdsb0IHtpnT0XIBA4f5pcd9FkbcTc'
		stat = sin.GetStat()
		if not temp_stat in stat:
			sin.setStats(temp_stat)
			text = f"====================\nNama Produk  : {nama}\nHarga Produk : {harga}\nStok Produk  : {stok}\nDikirim Dari : {kirim}\n====================\n\nLink Produk  : {response.url}"
			sin.Kirim_Pesan(user_id, text)